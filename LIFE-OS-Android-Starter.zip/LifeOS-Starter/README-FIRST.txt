LIFE OS — ANDROID STARTER PROJECT
Version: 0.1.0

IMPORTANT
This is a starter source project, not a finished app. It has not yet been built or tested on an Android phone. The GitHub Actions workflow is included to attempt a free cloud build.

WHAT IS INCLUDED
- Native Android project using Kotlin + Jetpack Compose
- Initial dashboard layout
- Home / Study / Fitness / Habits navigation
- Manual dark/light theme switch
- GitHub Actions workflow to build a debug APK

NOT INCLUDED YET
- Persistent database
- Actual study/workout/habit logging
- Automatic timestamps and statistics
- Notifications, timers, backup/export
- Automatic system theme following
These will be implemented and tested in later stages.

HOW TO START FROM AN IPAD
1. Sign in to GitHub in Safari and create a NEW repository named life-os.
2. For the easiest no-cost setup, choose Public. This makes source code visible to everyone. Do not put personal records, photos, passwords, tokens, or private information in this repository.
3. On the new repository page, choose Add file > Upload files.
4. Extract this ZIP first using the iPad Files app. Upload the CONTENTS of the LifeOS-Starter folder, including the hidden .github folder. If the .github folder is not visible, use the GitHub web upload workflow carefully or the repository's web editor to create the workflow file.
5. Commit the files to the main branch.
6. Open the repository's Actions tab. Select "Build LIFE OS APK" and choose Run workflow if it has not started automatically.
7. Wait for the workflow to finish. If successful, open the run and download the "LIFE-OS-debug-apk" artifact.
8. Transfer the APK to your Android phone and install it. Android may ask you to allow installation from the browser/files app you used. Only install the APK you built from your own repository.

FREE-TIER NOTE
GitHub Actions usage is subject to GitHub's current plan limits and policies. A public repository can make source code public. Do not add any personal app data to the repository.

NEXT MILESTONE
Get the starter APK built and installed. Then add local storage and real logging. Do not treat the app as complete until each feature is tested on the phone.
