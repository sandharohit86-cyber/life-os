package com.lifeos.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF101827)
private val Panel = Color(0xFF1B293B)
private val Accent = Color(0xFF9BC7FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LifeOSApp() }
    }
}

@Composable
fun LifeOSApp() {
    var dark by remember { mutableStateOf(true) }
    var selected by remember { mutableStateOf("Home") }
    val background = if (dark) Ink else Color(0xFFF3F6FA)
    val foreground = if (dark) Color.White else Color(0xFF172033)
    val card = if (dark) Panel else Color.White

    MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
        Scaffold(
            containerColor = background,
            bottomBar = {
                NavigationBar(containerColor = card) {
                    listOf("Home", "Study", "Fitness", "Habits").forEach { item ->
                        NavigationBarItem(
                            selected = selected == item,
                            onClick = { selected = item },
                            icon = {
                                Icon(
                                    imageVector = when (item) {
                                        "Study" -> Icons.Default.MenuBook
                                        "Fitness" -> Icons.Default.FitnessCenter
                                        "Habits" -> Icons.Default.CheckCircle
                                        else -> Icons.Default.Home
                                    },
                                    contentDescription = item
                                )
                            },
                            label = { Text(item) }
                        )
                    }
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("LIFE OS", color = foreground, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                            Text("YOUR PERSONAL DASHBOARD", color = foreground.copy(alpha = .6f), fontSize = 10.sp, letterSpacing = 1.5.sp)
                        }
                        IconButton(onClick = { dark = !dark }) {
                            Icon(if (dark) Icons.Default.LightMode else Icons.Default.DarkMode,
                                contentDescription = "Switch theme", tint = foreground)
                        }
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(22.dp)) {
                        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("GOOD DAY", color = foreground.copy(alpha = .65f), fontSize = 11.sp, letterSpacing = 1.4.sp)
                            Text(selected, color = foreground, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                            Text("Build your day one small action at a time.", color = foreground.copy(alpha = .7f))
                            LinearProgressIndicator(progress = { 0f }, modifier = Modifier.fillMaxWidth(), color = Accent)
                            Text("Your daily progress will appear here as you log activities.", color = foreground.copy(alpha = .6f), fontSize = 12.sp)
                        }
                    }
                }
                item { SectionHeading("QUICK LOG", foreground) }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        QuickAction("Study", Icons.Default.MenuBook, card, foreground) { selected = "Study" }
                        QuickAction("Workout", Icons.Default.FitnessCenter, card, foreground) { selected = "Fitness" }
                        QuickAction("Habit", Icons.Default.CheckCircle, card, foreground) { selected = "Habits" }
                    }
                }
                item { SectionHeading("YOUR WORKSPACES", foreground) }
                item {
                    WorkspaceCard("Study Centre", "Sessions, chapters and revision", Icons.Default.School, card, foreground) { selected = "Study" }
                }
                item {
                    WorkspaceCard("Fitness Centre", "Movement, recovery and activity logs", Icons.Default.FitnessCenter, card, foreground) { selected = "Fitness" }
                }
                item {
                    WorkspaceCard("Habits & Lifestyle", "Daily habits and personal routines", Icons.Default.TrackChanges, card, foreground) { selected = "Habits" }
                }
                item {
                    Text("STARTER BUILD • 0.1.0", color = foreground.copy(alpha = .45f), fontSize = 10.sp,
                        modifier = Modifier.fillMaxWidth().padding(top = 12.dp))
                }
            }
        }
    }
}

@Composable
private fun SectionHeading(text: String, color: Color) {
    Text(text, color = color.copy(alpha = .65f), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
}

@Composable
private fun RowScope.QuickAction(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    card: Color,
    foreground: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier.weight(1f).clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = card),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(vertical = 18.dp), horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, contentDescription = null, tint = Accent)
            Text(label, color = foreground, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun WorkspaceCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    card: Color,
    foreground: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = card),
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Icon(icon, contentDescription = null, tint = Accent, modifier = Modifier.size(28.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, color = foreground, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = foreground.copy(alpha = .6f), fontSize = 12.sp)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = foreground.copy(alpha = .5f))
        }
    }
}
